package com.eryck.estoque;

public class Filial {
}
