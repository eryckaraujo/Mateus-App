package com.eryck.estoque;

public class Estoque {
}
