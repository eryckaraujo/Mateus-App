package com.eryck.estoque;

public class PedidoEstoque {
}
