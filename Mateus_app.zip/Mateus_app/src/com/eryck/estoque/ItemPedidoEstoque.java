package com.eryck.estoque;

public class ItemPedidoEstoque {
}
